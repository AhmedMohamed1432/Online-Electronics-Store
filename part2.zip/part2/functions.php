<?php

// require MySQL Connection
require ('database/connection.php');

// require Product Class
require ('database/data.php');

require ('database/search.php');

require ('database/cart.php');

require ('database/favourite.php');

require ('database/returnProd.php');

require ('database/userBalance.php');

require ('database/checkout.php');

require ('database/addCusShipping.php');

// returnProduct ( 1 , 'Samsung Galaxy 10' , 1 ) ;
