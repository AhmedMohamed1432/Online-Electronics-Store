<!DOCTYPE html>
<html>
<body>
<center>
<h1>Products</h1>

<font>

<form action="/action_page.php"> <b>

  <label for="fname">Product name:</label><br> <b>
  <input type="text" id="fname" name="fname" value="write here"><br> <br>
  
  <label for="fname">Category name:</label><br> <b>
  <input type="text" id="fname" name="fname" value="write here"><br> <br>
  
  <label for="fname">Product image link:</label><br> <b>
  <input type="text" id="fname" name="fname" value="write here"><br> <br>
 
  <label for="fname">Manifacture name:</label><br> 
  <input type="text" id="fname" name="fname" value="write here"><br> <br>
  
  <label for="fname">Technical spes:</label><br> 
  <input type="text" id="fname" name="fname" value="write here"><br> <br>
 
  <label for="fname">Price double:</label><br> 
  <input type="text" id="fname" name="fname" value="write here"><br> <br>
  
  <label for="fname">Quantity Avalilable New INT:</label><br> 
  <input type="text" id="fname" name="fname" value="write here"><br> <br>
  
  <label for="fname">Quantity Avalilable Ref INT:</label><br> 
  <input type="text" id="fname" name="fname" value="write here"><br> <br>
  
  <label for="fname">Discount Double:</label><br> 
  <input type="text" id="fname" name="fname" value="write here"><br> <br>


<label for="the form above">Select if the product is new or inserted before: </label>
<select id="=">
  <option value="">--Make a choice--</option>
  <option value="new">New Product</option>
  <option value="old">Old product</option>
</select>
<p></p>
 
 
<input type="submit" value="Submit"
       style="background-color:#008080; 
              border: solid 4px #000000;
              height: 45px; 
              font-size:25px; 
              vertical-align:20px" />
              

</form> 
 
</body>

</html>